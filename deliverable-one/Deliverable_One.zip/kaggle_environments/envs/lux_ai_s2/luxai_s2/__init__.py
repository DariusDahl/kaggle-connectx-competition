from .env import LuxAI_S2
from .version import __version__
